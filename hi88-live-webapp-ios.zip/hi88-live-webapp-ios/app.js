(function() {
  const cfg = window.APP_CONFIG || {};
  const video = document.getElementById('player');
  const loading = document.getElementById('loading');
  const unmuteBtn = document.getElementById('unmuteBtn');
  const ctaBtn = document.getElementById('ctaBtn');
  const bannerImg = document.getElementById('bannerImg');
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  // Banner & CTA
  if (bannerImg && cfg.BANNER_IMG) bannerImg.src = cfg.BANNER_IMG;
  if (ctaBtn) {
    ctaBtn.textContent = cfg.CTA_TEXT || 'Tham gia ngay';
    ctaBtn.href = cfg.CTA_URL || '#';
  }

  // Player
  let triedUnmute = false;

  function onCanPlay() {
    loading.classList.add('hidden');
  }
  function onWaiting() {
    loading.classList.remove('hidden');
  }
  function onPlay() {
    loading.classList.add('hidden');
  }
  function onError(e) {
    console.warn('Player error', e);
    loading.classList.remove('hidden');
  }

  video.addEventListener('canplay', onCanPlay);
  video.addEventListener('waiting', onWaiting);
  video.addEventListener('playing', onPlay);
  video.addEventListener('error', onError);

  // Setup HLS
  async function setupPlayer() {
    const src = cfg.STREAM_URL;
    if (!src) return;

    // iOS Safari can play HLS natively
    if (video.canPlayType('application/vnd.apple.mpegURL')) {
      video.src = src;
    } else if (window.Hls && window.Hls.isSupported()) {
      const hls = new Hls({ maxBufferLength: 30, maxMaxBufferLength: 60 });
      hls.loadSource(src);
      hls.attachMedia(video);
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data?.fatal) {
          console.error('HLS fatal error:', data);
        }
      });
    } else if (cfg.FALLBACK_MP4) {
      video.src = cfg.FALLBACK_MP4;
    } else {
      console.error('HLS not supported and no fallback provided.');
    }

    // Autoplay strategy
    try {
      if (cfg.AUTOPLAY_WITH_SOUND) {
        video.muted = false;
        await video.play();
        unmuteBtn.hidden = true;
      } else {
        video.muted = true;
        await video.play();
        unmuteBtn.hidden = false;
      }
    } catch (err) {
      // If blocked, try muted autoplay and show unmute button
      try {
        video.muted = true;
        await video.play();
        unmuteBtn.hidden = false;
      } catch (e) {
        console.warn('Autoplay failed:', e);
      }
    }
  }

  unmuteBtn.addEventListener('click', async () => {
    try {
      video.muted = false;
      await video.play();
      unmuteBtn.hidden = true;
    } catch (e) {
      console.warn('Unmute failed', e);
    }
  });

  // PWA install prompt
  const installBtn = document.getElementById('installBtn');
  let deferredPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installBtn.hidden = false;
  });
  installBtn?.addEventListener('click', async () => {
    installBtn.hidden = true;
    deferredPrompt?.prompt();
    deferredPrompt = null;
  });

  setupPlayer();
})();
