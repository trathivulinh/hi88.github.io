# HI88 Live Web App (PWA)
Web app xem live 16:9 + banner, auto-play (có fallback bật tiếng), PWA cài lên mobile.

## Cấu hình nhanh
- Mở `config.js` và sửa:
  - `STREAM_URL` = link HLS (.m3u8) của bạn
  - `CTA_URL` = link khuyến mãi/đăng ký
  - (tuỳ chọn) `BANNER_IMG`, `FALLBACK_MP4`
- Đổi `assets/banner.png`, `assets/poster.jpg`, `assets/favicon.png` theo brand của bạn.

## Chạy local
Dùng bất kỳ HTTP server tĩnh nào (cần vì Service Worker):
```bash
# Python3
cd hi88-live-webapp
python3 -m http.server 8080
```
Mở http://localhost:8080/

## Deploy
- GitHub Pages / Cloudflare Pages / Netlify đều OK (chỉ cần upload folder).
- Nhớ bật HTTPS để PWA hoạt động đầy đủ.

## Ghi chú autoplay
- iOS thường chặn autoplay kèm tiếng. App sẽ thử auto-play có tiếng, nếu bị chặn sẽ phát mute và hiện nút **Bật tiếng**.
