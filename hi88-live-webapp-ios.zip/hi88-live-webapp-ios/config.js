// Edit these values to your actual stream/page.
window.APP_CONFIG = {
  STREAM_URL: "https://example.com/live/playlist.m3u8",   // <-- Đặt link HLS .m3u8 của bạn
  FALLBACK_MP4: "",                                       // <-- (Tuỳ chọn) link MP4 fallback khi không có HLS
  AUTOPLAY_WITH_SOUND: true,                               // Cố gắng phát kèm tiếng
  LIVE_TITLE: "HI88 - Xem Live Trực Tuyến",
  LIVE_DESC: "Khuyến mãi mỗi ngày. Tham gia ngay để nhận quà hấp dẫn!",
  BANNER_IMG: "./assets/banner.png",
  CTA_TEXT: "Tham gia ngay",
  CTA_URL: "https://hi88r.pro/"
};
